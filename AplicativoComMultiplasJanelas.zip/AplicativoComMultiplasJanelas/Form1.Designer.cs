﻿namespace AplicativoComMultiplasJanelas
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			buttonAdicionarProduto = new Button();
			buttonDeletarProduto = new Button();
			dataGridView1 = new DataGridView();
			buttonVerProdutos = new Button();
			buttonVerClientes = new Button();
			buttonVerFornecedores = new Button();
			buttonVerCompras = new Button();
			buttonVerVendas = new Button();
			buttonAdicionarFornecedor = new Button();
			buttonDeletarFornecedor = new Button();
			buttonAdicionarCliente = new Button();
			buttonDeletarCliente = new Button();
			buttonAdicionarCompra = new Button();
			buttonDeletarCompra = new Button();
			buttonAdicionarVenda = new Button();
			buttonDeletarVenda = new Button();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			// 
			// buttonAdicionarProduto
			// 
			buttonAdicionarProduto.BackColor = Color.FromArgb(255, 128, 128);
			buttonAdicionarProduto.FlatStyle = FlatStyle.Flat;
			buttonAdicionarProduto.ForeColor = Color.Maroon;
			buttonAdicionarProduto.Location = new Point(12, 53);
			buttonAdicionarProduto.Name = "buttonAdicionarProduto";
			buttonAdicionarProduto.Size = new Size(150, 23);
			buttonAdicionarProduto.TabIndex = 0;
			buttonAdicionarProduto.Text = "Novo Produto";
			buttonAdicionarProduto.UseVisualStyleBackColor = false;
			buttonAdicionarProduto.Click += buttonAdicionarProduto_Click;
			// 
			// buttonDeletarProduto
			// 
			buttonDeletarProduto.BackColor = Color.FromArgb(255, 128, 128);
			buttonDeletarProduto.FlatStyle = FlatStyle.Flat;
			buttonDeletarProduto.ForeColor = Color.Maroon;
			buttonDeletarProduto.Location = new Point(12, 76);
			buttonDeletarProduto.Name = "buttonDeletarProduto";
			buttonDeletarProduto.Size = new Size(150, 23);
			buttonDeletarProduto.TabIndex = 1;
			buttonDeletarProduto.Text = "Deletar Produto";
			buttonDeletarProduto.UseVisualStyleBackColor = false;
			buttonDeletarProduto.Click += buttonDeletarProduto_Click;
			// 
			// dataGridView1
			// 
			dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Location = new Point(12, 105);
			dataGridView1.Name = "dataGridView1";
			dataGridView1.Size = new Size(750, 420);
			dataGridView1.TabIndex = 2;
			dataGridView1.UserAddedRow += dataGridView1_UserAddedRow;
			// 
			// buttonVerProdutos
			// 
			buttonVerProdutos.BackColor = Color.FromArgb(255, 128, 128);
			buttonVerProdutos.FlatStyle = FlatStyle.Flat;
			buttonVerProdutos.ForeColor = Color.Maroon;
			buttonVerProdutos.Location = new Point(12, 12);
			buttonVerProdutos.Name = "buttonVerProdutos";
			buttonVerProdutos.Size = new Size(150, 41);
			buttonVerProdutos.TabIndex = 3;
			buttonVerProdutos.Text = "Produtos";
			buttonVerProdutos.UseVisualStyleBackColor = false;
			buttonVerProdutos.Click += buttonVerProdutos_Click;
			// 
			// buttonVerClientes
			// 
			buttonVerClientes.BackColor = Color.FromArgb(255, 128, 255);
			buttonVerClientes.FlatStyle = FlatStyle.Flat;
			buttonVerClientes.ForeColor = Color.FromArgb(64, 0, 64);
			buttonVerClientes.Location = new Point(312, 12);
			buttonVerClientes.Name = "buttonVerClientes";
			buttonVerClientes.Size = new Size(150, 41);
			buttonVerClientes.TabIndex = 4;
			buttonVerClientes.Text = "Clientes";
			buttonVerClientes.UseVisualStyleBackColor = false;
			buttonVerClientes.Click += buttonVerClientes_Click;
			// 
			// buttonVerFornecedores
			// 
			buttonVerFornecedores.BackColor = Color.FromArgb(128, 255, 128);
			buttonVerFornecedores.FlatStyle = FlatStyle.Flat;
			buttonVerFornecedores.ForeColor = Color.FromArgb(0, 64, 0);
			buttonVerFornecedores.Location = new Point(162, 12);
			buttonVerFornecedores.Name = "buttonVerFornecedores";
			buttonVerFornecedores.Size = new Size(150, 41);
			buttonVerFornecedores.TabIndex = 4;
			buttonVerFornecedores.Text = "Fornecedores";
			buttonVerFornecedores.UseVisualStyleBackColor = false;
			buttonVerFornecedores.Click += buttonVerFornecedores_Click;
			// 
			// buttonVerCompras
			// 
			buttonVerCompras.BackColor = Color.FromArgb(255, 255, 128);
			buttonVerCompras.FlatStyle = FlatStyle.Flat;
			buttonVerCompras.ForeColor = Color.FromArgb(64, 64, 0);
			buttonVerCompras.Location = new Point(462, 12);
			buttonVerCompras.Name = "buttonVerCompras";
			buttonVerCompras.Size = new Size(150, 41);
			buttonVerCompras.TabIndex = 4;
			buttonVerCompras.Text = "Compras";
			buttonVerCompras.UseVisualStyleBackColor = false;
			buttonVerCompras.Click += buttonVerCompras_Click;
			// 
			// buttonVerVendas
			// 
			buttonVerVendas.BackColor = Color.FromArgb(255, 192, 128);
			buttonVerVendas.FlatStyle = FlatStyle.Flat;
			buttonVerVendas.ForeColor = Color.FromArgb(128, 64, 64);
			buttonVerVendas.Location = new Point(612, 12);
			buttonVerVendas.Name = "buttonVerVendas";
			buttonVerVendas.Size = new Size(150, 41);
			buttonVerVendas.TabIndex = 4;
			buttonVerVendas.Text = "Vendas";
			buttonVerVendas.UseVisualStyleBackColor = false;
			buttonVerVendas.Click += buttonVerVendas_Click;
			// 
			// buttonAdicionarFornecedor
			// 
			buttonAdicionarFornecedor.BackColor = Color.FromArgb(128, 255, 128);
			buttonAdicionarFornecedor.FlatStyle = FlatStyle.Flat;
			buttonAdicionarFornecedor.ForeColor = Color.FromArgb(0, 64, 0);
			buttonAdicionarFornecedor.Location = new Point(162, 53);
			buttonAdicionarFornecedor.Name = "buttonAdicionarFornecedor";
			buttonAdicionarFornecedor.Size = new Size(150, 23);
			buttonAdicionarFornecedor.TabIndex = 0;
			buttonAdicionarFornecedor.Text = "Novo Fornecedor";
			buttonAdicionarFornecedor.UseVisualStyleBackColor = false;
			buttonAdicionarFornecedor.Click += buttonAdicionarFornecedor_Click;
			// 
			// buttonDeletarFornecedor
			// 
			buttonDeletarFornecedor.BackColor = Color.FromArgb(128, 255, 128);
			buttonDeletarFornecedor.FlatStyle = FlatStyle.Flat;
			buttonDeletarFornecedor.ForeColor = Color.FromArgb(0, 64, 0);
			buttonDeletarFornecedor.Location = new Point(162, 76);
			buttonDeletarFornecedor.Name = "buttonDeletarFornecedor";
			buttonDeletarFornecedor.Size = new Size(150, 23);
			buttonDeletarFornecedor.TabIndex = 1;
			buttonDeletarFornecedor.Text = "Deletar Fornecedor";
			buttonDeletarFornecedor.UseVisualStyleBackColor = false;
			buttonDeletarFornecedor.Click += buttonDeletarFornecedor_Click;
			// 
			// buttonAdicionarCliente
			// 
			buttonAdicionarCliente.BackColor = Color.FromArgb(255, 128, 255);
			buttonAdicionarCliente.FlatStyle = FlatStyle.Flat;
			buttonAdicionarCliente.ForeColor = Color.FromArgb(64, 0, 64);
			buttonAdicionarCliente.Location = new Point(312, 53);
			buttonAdicionarCliente.Name = "buttonAdicionarCliente";
			buttonAdicionarCliente.Size = new Size(150, 23);
			buttonAdicionarCliente.TabIndex = 0;
			buttonAdicionarCliente.Text = "Novo Cliente";
			buttonAdicionarCliente.UseVisualStyleBackColor = false;
			buttonAdicionarCliente.Click += buttonAdicionarCliente_Click;
			// 
			// buttonDeletarCliente
			// 
			buttonDeletarCliente.BackColor = Color.FromArgb(255, 128, 255);
			buttonDeletarCliente.FlatStyle = FlatStyle.Flat;
			buttonDeletarCliente.ForeColor = Color.FromArgb(64, 0, 64);
			buttonDeletarCliente.Location = new Point(312, 76);
			buttonDeletarCliente.Name = "buttonDeletarCliente";
			buttonDeletarCliente.Size = new Size(150, 23);
			buttonDeletarCliente.TabIndex = 1;
			buttonDeletarCliente.Text = "Deletar Cliente";
			buttonDeletarCliente.UseVisualStyleBackColor = false;
			buttonDeletarCliente.Click += buttonDeletarCliente_Click;
			// 
			// buttonAdicionarCompra
			// 
			buttonAdicionarCompra.BackColor = Color.FromArgb(255, 255, 128);
			buttonAdicionarCompra.FlatStyle = FlatStyle.Flat;
			buttonAdicionarCompra.ForeColor = Color.FromArgb(64, 64, 0);
			buttonAdicionarCompra.Location = new Point(462, 53);
			buttonAdicionarCompra.Name = "buttonAdicionarCompra";
			buttonAdicionarCompra.Size = new Size(150, 23);
			buttonAdicionarCompra.TabIndex = 0;
			buttonAdicionarCompra.Text = "Nova Compra";
			buttonAdicionarCompra.UseVisualStyleBackColor = false;
			buttonAdicionarCompra.Click += buttonAdicionarCompra_Click;
			// 
			// buttonDeletarCompra
			// 
			buttonDeletarCompra.BackColor = Color.FromArgb(255, 255, 128);
			buttonDeletarCompra.FlatStyle = FlatStyle.Flat;
			buttonDeletarCompra.ForeColor = Color.FromArgb(64, 64, 0);
			buttonDeletarCompra.Location = new Point(462, 76);
			buttonDeletarCompra.Name = "buttonDeletarCompra";
			buttonDeletarCompra.Size = new Size(150, 23);
			buttonDeletarCompra.TabIndex = 1;
			buttonDeletarCompra.Text = "Deletar Compra";
			buttonDeletarCompra.UseVisualStyleBackColor = false;
			buttonDeletarCompra.Click += buttonDeletarCompra_Click;
			// 
			// buttonAdicionarVenda
			// 
			buttonAdicionarVenda.BackColor = Color.FromArgb(255, 192, 128);
			buttonAdicionarVenda.FlatStyle = FlatStyle.Flat;
			buttonAdicionarVenda.ForeColor = Color.FromArgb(128, 64, 64);
			buttonAdicionarVenda.Location = new Point(612, 53);
			buttonAdicionarVenda.Name = "buttonAdicionarVenda";
			buttonAdicionarVenda.Size = new Size(150, 23);
			buttonAdicionarVenda.TabIndex = 0;
			buttonAdicionarVenda.Text = "Nova Venda";
			buttonAdicionarVenda.UseVisualStyleBackColor = false;
			buttonAdicionarVenda.Click += buttonAdicionarVenda_Click;
			// 
			// buttonDeletarVenda
			// 
			buttonDeletarVenda.BackColor = Color.FromArgb(255, 192, 128);
			buttonDeletarVenda.FlatStyle = FlatStyle.Flat;
			buttonDeletarVenda.ForeColor = Color.FromArgb(128, 64, 64);
			buttonDeletarVenda.Location = new Point(612, 76);
			buttonDeletarVenda.Name = "buttonDeletarVenda";
			buttonDeletarVenda.Size = new Size(150, 23);
			buttonDeletarVenda.TabIndex = 1;
			buttonDeletarVenda.Text = "Deletar Venda";
			buttonDeletarVenda.UseVisualStyleBackColor = false;
			buttonDeletarVenda.Click += buttonDeletarVenda_Click;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(769, 537);
			Controls.Add(buttonVerVendas);
			Controls.Add(buttonVerCompras);
			Controls.Add(buttonVerFornecedores);
			Controls.Add(buttonVerClientes);
			Controls.Add(buttonVerProdutos);
			Controls.Add(dataGridView1);
			Controls.Add(buttonDeletarVenda);
			Controls.Add(buttonDeletarCompra);
			Controls.Add(buttonDeletarCliente);
			Controls.Add(buttonDeletarFornecedor);
			Controls.Add(buttonDeletarProduto);
			Controls.Add(buttonAdicionarVenda);
			Controls.Add(buttonAdicionarCompra);
			Controls.Add(buttonAdicionarCliente);
			Controls.Add(buttonAdicionarFornecedor);
			Controls.Add(buttonAdicionarProduto);
			Name = "Form1";
			Text = "Form1";
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}

		#endregion

		private Button buttonAdicionarProduto;
		private Button buttonDeletarProduto;
		private DataGridView dataGridView1;
		private Button buttonVerProdutos;
		private Button buttonVerClientes;
		private Button buttonVerFornecedores;
		private Button buttonVerCompras;
		private Button buttonVerVendas;
		private Button buttonAdicionarFornecedor;
		private Button buttonDeletarFornecedor;
		private Button buttonAdicionarCliente;
		private Button buttonDeletarCliente;
		private Button buttonAdicionarCompra;
		private Button buttonDeletarCompra;
		private Button buttonAdicionarVenda;
		private Button buttonDeletarVenda;
	}
}
