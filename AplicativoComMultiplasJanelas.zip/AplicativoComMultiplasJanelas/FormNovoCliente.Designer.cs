﻿namespace AplicativoComMultiplasJanelas
{
	partial class FormNovoCliente
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			groupBox1 = new GroupBox();
			label9 = new Label();
			label8 = new Label();
			label7 = new Label();
			label6 = new Label();
			label5 = new Label();
			label4 = new Label();
			textBoxEnderecoCEP = new TextBox();
			textBoxEnderecoEstado = new TextBox();
			textBoxEnderecoCidade = new TextBox();
			textBoxEnderecoComplemento = new TextBox();
			textBoxEnderecoNumero = new TextBox();
			textBoxEnderecoLogradouro = new TextBox();
			textBoxEmail = new TextBox();
			textBoxTelefone = new TextBox();
			textBoxNome = new TextBox();
			label3 = new Label();
			label2 = new Label();
			label1 = new Label();
			buttonCancelar = new Button();
			buttonOk = new Button();
			groupBox1.SuspendLayout();
			SuspendLayout();
			// 
			// groupBox1
			// 
			groupBox1.Controls.Add(label9);
			groupBox1.Controls.Add(label8);
			groupBox1.Controls.Add(label7);
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(textBoxEnderecoCEP);
			groupBox1.Controls.Add(textBoxEnderecoEstado);
			groupBox1.Controls.Add(textBoxEnderecoCidade);
			groupBox1.Controls.Add(textBoxEnderecoComplemento);
			groupBox1.Controls.Add(textBoxEnderecoNumero);
			groupBox1.Controls.Add(textBoxEnderecoLogradouro);
			groupBox1.Location = new Point(12, 93);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new Size(310, 199);
			groupBox1.TabIndex = 17;
			groupBox1.TabStop = false;
			groupBox1.Text = "Endereço";
			// 
			// label9
			// 
			label9.AutoSize = true;
			label9.Location = new Point(6, 169);
			label9.Name = "label9";
			label9.Size = new Size(31, 15);
			label9.TabIndex = 8;
			label9.Text = "CEP:";
			// 
			// label8
			// 
			label8.AutoSize = true;
			label8.Location = new Point(6, 140);
			label8.Name = "label8";
			label8.Size = new Size(70, 15);
			label8.TabIndex = 8;
			label8.Text = "UF (Estado):";
			// 
			// label7
			// 
			label7.AutoSize = true;
			label7.Location = new Point(6, 111);
			label7.Name = "label7";
			label7.Size = new Size(47, 15);
			label7.TabIndex = 8;
			label7.Text = "Cidade:";
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Location = new Point(6, 83);
			label6.Name = "label6";
			label6.Size = new Size(87, 15);
			label6.TabIndex = 8;
			label6.Text = "Complemento:";
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Location = new Point(6, 54);
			label5.Name = "label5";
			label5.Size = new Size(54, 15);
			label5.TabIndex = 8;
			label5.Text = "Numero:";
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new Point(6, 25);
			label4.Name = "label4";
			label4.Size = new Size(103, 15);
			label4.TabIndex = 8;
			label4.Text = "Logradouro (Rua):";
			// 
			// textBoxEnderecoCEP
			// 
			textBoxEnderecoCEP.Location = new Point(112, 166);
			textBoxEnderecoCEP.Name = "textBoxEnderecoCEP";
			textBoxEnderecoCEP.Size = new Size(192, 23);
			textBoxEnderecoCEP.TabIndex = 8;
			// 
			// textBoxEnderecoEstado
			// 
			textBoxEnderecoEstado.Location = new Point(112, 137);
			textBoxEnderecoEstado.Name = "textBoxEnderecoEstado";
			textBoxEnderecoEstado.Size = new Size(192, 23);
			textBoxEnderecoEstado.TabIndex = 7;
			// 
			// textBoxEnderecoCidade
			// 
			textBoxEnderecoCidade.Location = new Point(112, 108);
			textBoxEnderecoCidade.Name = "textBoxEnderecoCidade";
			textBoxEnderecoCidade.Size = new Size(192, 23);
			textBoxEnderecoCidade.TabIndex = 6;
			// 
			// textBoxEnderecoComplemento
			// 
			textBoxEnderecoComplemento.Location = new Point(112, 80);
			textBoxEnderecoComplemento.Name = "textBoxEnderecoComplemento";
			textBoxEnderecoComplemento.Size = new Size(192, 23);
			textBoxEnderecoComplemento.TabIndex = 5;
			// 
			// textBoxEnderecoNumero
			// 
			textBoxEnderecoNumero.Location = new Point(112, 51);
			textBoxEnderecoNumero.Name = "textBoxEnderecoNumero";
			textBoxEnderecoNumero.Size = new Size(192, 23);
			textBoxEnderecoNumero.TabIndex = 4;
			// 
			// textBoxEnderecoLogradouro
			// 
			textBoxEnderecoLogradouro.Location = new Point(112, 22);
			textBoxEnderecoLogradouro.Name = "textBoxEnderecoLogradouro";
			textBoxEnderecoLogradouro.Size = new Size(192, 23);
			textBoxEnderecoLogradouro.TabIndex = 3;
			// 
			// textBoxEmail
			// 
			textBoxEmail.Location = new Point(124, 64);
			textBoxEmail.Name = "textBoxEmail";
			textBoxEmail.Size = new Size(198, 23);
			textBoxEmail.TabIndex = 13;
			// 
			// textBoxTelefone
			// 
			textBoxTelefone.Location = new Point(124, 35);
			textBoxTelefone.Name = "textBoxTelefone";
			textBoxTelefone.Size = new Size(198, 23);
			textBoxTelefone.TabIndex = 12;
			// 
			// textBoxNome
			// 
			textBoxNome.Location = new Point(124, 6);
			textBoxNome.Name = "textBoxNome";
			textBoxNome.Size = new Size(198, 23);
			textBoxNome.TabIndex = 11;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new Point(12, 67);
			label3.Name = "label3";
			label3.Size = new Size(47, 15);
			label3.TabIndex = 16;
			label3.Text = "E-mail: ";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(12, 38);
			label2.Name = "label2";
			label2.Size = new Size(57, 15);
			label2.TabIndex = 15;
			label2.Text = "Telefone: ";
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(12, 9);
			label1.Name = "label1";
			label1.Size = new Size(46, 15);
			label1.TabIndex = 14;
			label1.Text = "Nome: ";
			// 
			// buttonCancelar
			// 
			buttonCancelar.Location = new Point(247, 298);
			buttonCancelar.Name = "buttonCancelar";
			buttonCancelar.Size = new Size(75, 23);
			buttonCancelar.TabIndex = 19;
			buttonCancelar.Text = "Cancelar";
			buttonCancelar.UseVisualStyleBackColor = true;
			buttonCancelar.Click += buttonCancelar_Click;
			// 
			// buttonOk
			// 
			buttonOk.Location = new Point(166, 298);
			buttonOk.Name = "buttonOk";
			buttonOk.Size = new Size(75, 23);
			buttonOk.TabIndex = 18;
			buttonOk.Text = "Ok";
			buttonOk.UseVisualStyleBackColor = true;
			buttonOk.Click += buttonOk_Click;
			// 
			// FormNovoCliente
			// 
			AcceptButton = buttonOk;
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			CancelButton = buttonCancelar;
			ClientSize = new Size(336, 329);
			Controls.Add(groupBox1);
			Controls.Add(textBoxEmail);
			Controls.Add(textBoxTelefone);
			Controls.Add(textBoxNome);
			Controls.Add(label3);
			Controls.Add(label2);
			Controls.Add(label1);
			Controls.Add(buttonCancelar);
			Controls.Add(buttonOk);
			Name = "FormNovoCliente";
			Text = "FormNovoCliente";
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private GroupBox groupBox1;
		private Label label9;
		private Label label8;
		private Label label7;
		private Label label6;
		private Label label5;
		private Label label4;
		private TextBox textBoxEnderecoCEP;
		private TextBox textBoxEnderecoEstado;
		private TextBox textBoxEnderecoCidade;
		private TextBox textBoxEnderecoComplemento;
		private TextBox textBoxEnderecoNumero;
		private TextBox textBoxEnderecoLogradouro;
		private TextBox textBoxEmail;
		private TextBox textBoxTelefone;
		private TextBox textBoxNome;
		private Label label3;
		private Label label2;
		private Label label1;
		private Button buttonCancelar;
		private Button buttonOk;
	}
}